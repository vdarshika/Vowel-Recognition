========================================================================
    CONSOLE APPLICATION : vowel_recognition Project Overview
========================================================================

===============================================================================
===================SPEECH PROCESSING ASSIGNMENT-3================================
===============================================================================
=========================DARSHIKA VERMA========================================
===========================214101014===========================================

===============================================================================
===============================================================================
INSTRUCTIONS TO FOLLOW TO RUN THE APPLICATION
===============================================================================
---->Pre-requisites for the application to run:
	1. All the files that contain the recording of vowels.
	2. vowel_recognitiob.cpp file.
 #Keep all the vowel files in the same folder where the cpp file is stored.


----> Step-1: Open the Microsoft Visual Studio 2010.
----> Step-2: Open the folder where the main program is stored.
----> Step-3: Compile and Run the program using the F5 key. The output will be displayed on the console window.

=================================================================================================================
=================================================================================================================


AppWizard has created this vowel_recognition application for you.

This file contains a summary of what you will find in each of the files that
make up your vowel_recognition application.


vowel_recognition.vcxproj
    This is the main project file for VC++ projects generated using an Application Wizard.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

vowel_recognition.vcxproj.filters
    This is the filters file for VC++ projects generated using an Application Wizard. 
    It contains information about the association between the files in your project 
    and the filters. This association is used in the IDE to show grouping of files with
    similar extensions under a specific node (for e.g. ".cpp" files are associated with the
    "Source Files" filter).

vowel_recognition.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named vowel_recognition.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
